### This is the drop script to drop oracle_staging schema and its tables.
#The second call in the file_infos recreates the DB###
import json
from airflow import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.contrib.operators.spark_sql_operator import SparkSqlOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta


def transform(parent_dag_name, default_args):

    # file_infos = [{'name': 'principal', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_principal.sql "},
    #               {'name': 'interest', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_interest.sql "},
    #               {'name': 'late_fee', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_late_fee.sql "},
    #               {'name': 'nsf_fee', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_nsf_fee.sql "},
    #               {'name': 'check_fee', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_check_fee.sql "},
    #               {'name': 'totalamt', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_txn_totalamt.sql "}
    #               ]

    file_infos = [{'name': 'transform_queries_all', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/transform_queries.sql "},
                  {'name': 'penny_test', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_je_penny_test.sql "},
                  {'name': 'installer_disbursement', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/oracle_je_installer_disbursement.sql "},
                  ]


    dag_childname = 'Transform'

    dag = DAG('%s.%s' % (parent_dag_name, dag_childname), 
	    concurrency = 300, 
		default_args = default_args)

    [ SparkSqlOperator(task_id = file_name['name'], yarn_queue='default', name = file_name['name'], sql = file_name['sql'], provide_context = True, dag = dag)
	    	for file_name in file_infos ]
    return dag