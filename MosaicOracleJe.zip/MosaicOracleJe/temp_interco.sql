use oracle_staging;
--insert overwrite table oracle_staging.oracle_je_data
--create or replace table oracle_je_data
--as
insert overwrite table oracle_staging.oracle_je_data
select * from oracle_staging.oracle_je_data
union
select  jed.id,
        'interco-cash' as source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_credit gl_debit,
        jed.gl_debit gl_credit,
        jed.gl_date,
        jed.effective_date,
        jed.facility_code,
        jed.facility_type_id,
        'interco_cash_data' as gl_description,
        jed.coa_seg_1,
        '10020' as coa_seg_2,
        glm.interco_cash_due_to coa_seg_4,
        coaseg5.coa_seg_1 as coa_seg_5,
        jed.transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
        jed.batch_name
from oracle_staging.oracle_je_data jed
left join oracle_staging.oracle_gl_mapping glm on (jed.je_type = glm.je_type and jed.transcode = glm.concord_code)
left join (select coa_seg_1, id, loan_id
        from oracle_staging.oracle_je_data
        where je_type in ('Borrower Payment')
        and lender_bank_account <> deposit_bank_account
        and gl_description in ('principal', 'interest', 'late_fee', 'check_fee', 'nsf_fee')
        group by coa_seg_1, id, loan_id) coaseg5 on (coaseg5.loan_id = jed.loan_id and coaseg5.id = jed.id)
where jed.je_type in ('Borrower Payment')
and lender_bank_account <> deposit_bank_account
and gl_description = 'offset_cash'
union
select  jed.id,
        'interco-cash' as source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        sum(jed.gl_credit) gl_debit,
        sum(jed.gl_debit) gl_credit,
        jed.gl_date,
        jed.effective_date,
        jed.facility_code,
        jed.facility_type_id,
        'interco_loan_data' as gl_description,
       -- jed.gl_description,
        jed.coa_seg_1,
        '10020' as coa_seg_2,
        glm.interco_cash_due_from coa_seg_4,
        coaseg5.coa_seg_1 as coa_seg_5,
        jed.transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
        jed.batch_name
from oracle_staging.oracle_je_data jed
left join oracle_staging.oracle_gl_mapping glm on (jed.je_type = glm.je_type and jed.transcode = glm.concord_code)
left join (select coa_seg_1, id, loan_id
        from oracle_staging.oracle_je_data
        where je_type in ('Borrower Payment')
        and lender_bank_account <> deposit_bank_account
        and gl_description = 'offset_cash'
        group by coa_seg_1, id, loan_id) coaseg5 on (coaseg5.loan_id = jed.loan_id and coaseg5.id = jed.id)
where jed.je_type in ('Borrower Payment')
and lender_bank_account <> deposit_bank_account
and gl_description in ('principal', 'interest', 'late_fee', 'check_fee', 'nsf_fee')
group by jed.id,
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_date,
        jed.effective_date,
        jed.facility_code,
        jed.facility_type_id,
       -- jed.gl_description,
        jed.coa_seg_1,
        coaseg5.coa_seg_1,
        glm.interco_cash_due_from,
        jed.transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
        jed.batch_name;