### This is the drop script to drop oracle_staging schema and its tables.
#The second call in the file_infos recreates the DB###
import json
from airflow import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.contrib.operators.spark_sql_operator import SparkSqlOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta


def drop_db(parent_dag_name, default_args):

    file_infos = [{'name': 'DropTables', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/drop_staging_db.sql "},
                  {'name': 'CreateDb', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/create_staging_db.sql "}
                  ]
    dag_childname = 'DropDb'

    dag = DAG('%s.%s' % (parent_dag_name, dag_childname), 
	    concurrency = 300, 
		default_args = default_args)

    [ SparkSqlOperator(task_id = file_name['name'], yarn_queue='default', name = file_name['name'], sql = file_name['sql'], provide_context = True, conf='spark.sql.warehouse.dir=s3://spark-hive-store-qa/', dag = dag)
	    	for file_name in file_infos ]
    return dag

# def DropDbOp(dag, dag_name):
# 	run_this = PythonOperator(
# 	    task_id='drop_from_hive_' + dag_name,
# 	    provide_context=True,
# 	    python_callable=DropDb,
# 	    dag=dag)
# 	return run_this