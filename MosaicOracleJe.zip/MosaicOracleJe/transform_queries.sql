use oracle_staging;
drop table if exists oracle_txn_principal;
create table oracle_txn_principal
as
select  txn_principal.id,
      txn_principal.developer, 
      txn_principal.project, 
      txn_principal.type as txn_type, 
      txn_principal.id concord_txn_id,
      txn_principal.post_date gl_date,
      COALESCE(case when txn_principal.principal > 0 then
          txn_principal.principal
      end, 0) credit, 
      COALESCE(case when txn_principal.principal < 0 then
          txn_principal.principal
      end, 0) debit, 	
      'principal' gl_description,
      txn_principal.lender_bank_account, 
      txn_principal.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(tw.gl_account as int), 1001) coa_seg_1, --tmemp using temp_warehouse for coa_seg_1
      '10020' as coa_seg_2,
      case when txn_principal.principal > 0 then
          gl_map.principal_account
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_principal.deposit_bank_account, length(txn_principal.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_principal.mosaic_loan_id,
      txn_principal.batch,
      'concord_loan' source
from oracle_staging.concord_txn txn_principal
left join  oracle_staging.warehouse w on w.id = txn_principal.lender -- cast(ltrim(txn_principal.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = txn_principal.lender
left join oracle_staging.oracle_gl_mapping gl_map on txn_principal.type = gl_map.concord_code
where txn_principal.principal > 0;

drop table if exists oracle_txn_interest;
create table oracle_txn_interest
as
select txn_interest.id, 
      txn_interest.developer, 
      txn_interest.project, 
      txn_interest.type as txn_type, 
      txn_interest.id concord_txn_id,
      txn_interest.post_date gl_date,
      COALESCE(case when txn_interest.interest > 0 then
           txn_interest.interest
      end, 0) credit,
       COALESCE(case when txn_interest.interest < 0 then
           txn_interest.interest
      end, 0) debit,        
      'interest' gl_description,
      txn_interest.lender_bank_account, 
      txn_interest.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(tw.gl_account as int), 1001) coa_seg_1,
      '10020' as coa_seg_2,
      case when txn_interest.interest > 0 then
          gl_map.interest
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_interest.deposit_bank_account, length(txn_interest.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_interest.mosaic_loan_id,
      txn_interest.batch,
      'concord_loan' source
from oracle_staging.concord_txn txn_interest
left join  oracle_staging.warehouse w on w.id = txn_interest.lender -- cast(ltrim(txn_interest.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = txn_interest.lender
left join oracle_staging.oracle_gl_mapping gl_map on txn_interest.type = gl_map.concord_code
where txn_interest.interest > 0 ;


drop table if exists oracle_txn_late_fee;
create table oracle_txn_late_fee
as
select  txn_late_fee.id,
      txn_late_fee.developer, 
      txn_late_fee.project, 
      txn_late_fee.type as txn_type, 
      txn_late_fee.id concord_txn_id,
      txn_late_fee.post_date gl_date,
      COALESCE(case when txn_late_fee.late_fee > 0 then
          txn_late_fee.late_fee
      end, 0) credit, 
      COALESCE(case when txn_late_fee.late_fee < 0 then
          txn_late_fee.late_fee
      end, 0) debit, 
      'late_fee' gl_description,
      txn_late_fee.lender_bank_account, 
      txn_late_fee.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(tw.gl_account as int), 1001) coa_seg_1,
      '10020' as coa_seg_2,
      case when txn_late_fee.late_fee > 0 then
          gl_map.late_fee
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_late_fee.deposit_bank_account, length(txn_late_fee.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_late_fee.mosaic_loan_id,
      txn_late_fee.batch,
      'concord_loan' source
from oracle_staging.concord_txn txn_late_fee
left join  oracle_staging.warehouse w on w.id = txn_late_fee.lender -- cast(ltrim(txn_late_fee.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = txn_late_fee.lender
left join oracle_staging.oracle_gl_mapping gl_map on txn_late_fee.type = gl_map.concord_code
where txn_late_fee.late_fee > 0;

drop table if exists oracle_txn_check_fee;
create table oracle_txn_check_fee
as
select txn_check_fee.id, 
      txn_check_fee.developer, 
      txn_check_fee.project, 
      txn_check_fee.type as txn_type, 
      txn_check_fee.id concord_txn_id,
      txn_check_fee.post_date gl_date,
      COALESCE(case when txn_check_fee.check_fee > 0 then
          txn_check_fee.check_fee
      end, 0) credit, 
      COALESCE(case when txn_check_fee.check_fee < 0 then
          txn_check_fee.check_fee
      end, 0) debit, 
      'check_fee' gl_description,
      txn_check_fee.lender_bank_account, 
      txn_check_fee.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(tw.gl_account as int), 1001) coa_seg_1,
      '10020' as coa_seg_2,
      case when txn_check_fee.check_fee > 0 then
          gl_map.late_fee
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_check_fee.deposit_bank_account, length(txn_check_fee.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_check_fee.mosaic_loan_id,
      txn_check_fee.batch,
      'concord_loan' source
from oracle_staging.concord_txn txn_check_fee
left join  oracle_staging.warehouse w on w.id = txn_check_fee.lender -- cast(ltrim(txn_check_fee.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = txn_check_fee.lender
left join oracle_staging.oracle_gl_mapping gl_map on txn_check_fee.type = gl_map.concord_code
where txn_check_fee.check_fee > 0;

drop table if exists oracle_txn_nsf_fee;
create table oracle_txn_nsf_fee
as
select txn_nsf_fee.id,  
      txn_nsf_fee.developer, 
      txn_nsf_fee.project, 
      txn_nsf_fee.type as txn_type, 
      txn_nsf_fee.id concord_txn_id,
      txn_nsf_fee.post_date gl_date,
      COALESCE(case when txn_nsf_fee.nsf_fee > 0 then
          txn_nsf_fee.nsf_fee
      end, 0) credit,  
      COALESCE(case when txn_nsf_fee.nsf_fee < 0 then
          txn_nsf_fee.nsf_fee
      end, 0) debit,
      'nsf_fee' gl_description,
      txn_nsf_fee.lender_bank_account, 
      txn_nsf_fee.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(tw.gl_account as int), 1001) coa_seg_1,
      '10020' as coa_seg_2,
      case when txn_nsf_fee.nsf_fee > 0 then
          gl_map.late_fee
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_nsf_fee.deposit_bank_account, length(txn_nsf_fee.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_nsf_fee.mosaic_loan_id,
      txn_nsf_fee.batch,
      'concord_loan' source
from oracle_staging.concord_txn txn_nsf_fee
left join  oracle_staging.warehouse w on w.id = txn_nsf_fee.lender -- cast(ltrim(txn_nsf_fee.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = txn_nsf_fee.lender
left join oracle_staging.oracle_gl_mapping gl_map on txn_nsf_fee.type = gl_map.concord_code
where txn_nsf_fee.nsf_fee > 0;

drop table if exists oracle_txn_totalamt;
create table oracle_txn_totalamt
as
select txn_total_amt.id,  
      txn_total_amt.developer, 
      txn_total_amt.project, 
      txn_total_amt.type as txn_type, 
      txn_total_amt.id concord_txn_id,
      txn_total_amt.post_date gl_date,
      COALESCE(case when txn_total_amt.total_amount < 0 then
          txn_total_amt.total_amount
      end, 0) credit, 
      COALESCE(case when txn_total_amt.total_amount > 0 then
          txn_total_amt.total_amount
      end, 0) debit, 
      'offset_cash' gl_description,
      txn_total_amt.lender_bank_account, 
      txn_total_amt.deposit_bank_account,
      gl_map.offset_account,
      gl_map.principal_account,
      COALESCE(CAST(w.gl_account as int), 1001) coa_seg_1, --this should always get coa_seg_1 from warehouse, the warehouse connection will change w temp etc
     -- COALESCE(CAST(temp_ach_account.gl_account as int), 1001) coa_seg_1,
      '10020' as coa_seg_2,
      case when txn_total_amt.total_amount > 0 then
          ach_account.gl_account_number
      end coa_seg_4,
      gl_map.je_type,
      w.facility_type_id,
      tw.on_book_facility,
      w.code warehouse_code,
      substring(txn_total_amt.deposit_bank_account, length(txn_total_amt.deposit_bank_account) - 3, 4) bank_account_last_four,
      txn_total_amt.mosaic_loan_id,
      txn_total_amt.batch,
      'concord_cash' source
from oracle_staging.concord_txn txn_total_amt
left join oracle_staging.oracle_gl_mapping gl_map on txn_total_amt.type = gl_map.concord_code
left join oracle_staging.ach_account ach_account on substring(txn_total_amt.deposit_bank_account, length(txn_total_amt.deposit_bank_account) - 3, 4) = ach_account.last_four
left join  oracle_staging.temp_oracle_ach_account temp_ach_account on temp_ach_account.id = ach_account.facility_id 
left join  oracle_staging.warehouse w on w.id = ach_account.facility_id -- txn_total_amt.lender -- cast(ltrim(txn_total_amt.lender, 0) as int)
left join  oracle_staging.temp_oracle_warehouse tw on tw.id = w.id
where txn_total_amt.total_amount > 0;