use oracle_staging;
drop table if exists oracle_je_installer_disbursement;
create table oracle_je_installer_disbursement
as
SELECT DISTINCT
  COALESCE(r.id, t.id) AS id, 
  'platform' AS source,
  'Installer Disb Rtn Rtry' as je_type,
  COALESCE(r.batch_id, t.batch_id) as batch_id,
  '' as loan_id,
  -- If the settlement date is on or after the ACH transfer date, use that as the gl date. 
  -- Otherwise, use the ACH date created.
  -- Unclear how to handle backdated payments...
  -- todo: Need to work with accounting for a standard approach that will support backdated payments
  case when r.id IS NULL then case when b.settlement_date >= DATE(from_utc_timestamp(from_unixtime(UNIX_TIMESTAMP(t.date_created)),'America/Los_Angeles')) then b.settlement_date else DATE(from_utc_timestamp(from_unixtime(UNIX_TIMESTAMP(t.date_created)),'America/Los_Angeles')) end else DATE(from_utc_timestamp(from_unixtime(UNIX_TIMESTAMP(t.date_created)),'America/Los_Angeles')) end AS gl_date,

  ach_account.last_four as bank_account_last_four,
  ach_account.description as gl_description,
  COALESCE(warehouse.gl_account, '1001') AS coa_seg_1,
  '00000' as coa_seg_2,
  ach_account.gl_account_number AS coa_seg_4,

  case when r.id IS NULL then CASE WHEN t.is_credit = 0 THEN t.amount	ELSE 0 END else r.debit_amount end AS gl_credit,
  case when r.id IS NULL then CASE WHEN t.is_credit = 1 THEN t.amount ELSE 0 END else r.credit_amount end AS gl_debit,

  'ach_transfer' AS platform_entity, 
  warehouse.facility_type_id AS facility_type_id,
  '' as on_book_facility,
  warehouse.code AS facility_code,
  t.transfer_category_id,
  0 as lender_bank_account,
  0 as deposit_bank_account
FROM oracle_staging.ach_transfer t
LEFT JOIN oracle_staging.ach_return r ON (t.id = r.individual_id AND r.return_type_code = 10)
JOIN oracle_staging.batch b ON b.id = COALESCE(r.batch_id, t.batch_id)
INNER JOIN oracle_staging.ach_account ON t.ach_account_id = ach_account.id
INNER JOIN oracle_staging.warehouse ON ach_account.facility_id = warehouse.id
LEFT JOIN oracle_staging.installer_disbursement id ON t.id = id.ach_transfer_id
LEFT JOIN (SELECT installer_disbursement_id, min(ach_transfer_id) as ach_transfer_id
      FROM oracle_staging.installer_disbursement_history
      GROUP BY installer_disbursement_id) first ON first.installer_disbursement_id = id.id
LEFT JOIN oracle_staging.installer_disbursement_history h ON id.id = h.installer_disbursement_id
WHERE t.transfer_category_id = 10 -- This is specifically for InstallerDisbursementEntity
and ((id.payment_status_id = 2 and h.ach_transfer_id != first.ach_transfer_id) or r.id IS NOT NULL)
and t.date_created >= '2018-06-01'
;