# all imports
import MosaicOracleJe.util_file as util_file

import json
from airflow import DAG
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta
import pandas as pd
import psycopg2
import boto3
#import logging
# import time, datetime, calendar
# from dateutil.parser import parse
# from datetime import timedelta



def redshift_setup(dbname, host, user, port = 5439, **kwargs):
    global connect, cursor
    connect = psycopg2.connect(dbname = dbname,
                                        host = host,
                                        port = port,
                                        user = user,
                                        **kwargs)



    cursor = connect.cursor()
    #now = datetime.datetime.now()
    #datetimestampvar = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    #if util_file.datetimestampvar != '':
        #datetimestampvar_local = util_file.datetimestampvar
    #else:
    datetimestampvar = util_file.get_date_timestamp()
    #logging.basicConfig(level=logging.INFO)
    #logger = logging.getLogger()
    table_info_file = "/home/hadoop/airflow/dags/MosaicOracleJe/redshift_tables_setup.json"
    with open(table_info_file) as handle:
        tbls = json.loads(handle.read())
    tables = tbls[0]['tables']  
    for table in tables:
        querydroptab = 'drop table if exists ' + table['table_name'] + ';'
        cursor.execute(querydroptab)
    #query = 'drop table if exists engineering.warehouse;'
    #cursor.execute(query)
       # logger.info('Past drop table in redshift command')
        util_file.get_logger_info('Past drop table in redshift command') 

    #with open(table_info_file) as handle:
    #    tbls = json.loads(handle.read())
    #tables = tbls[0]['tables']  
    #for table in tables:
        queryrecreatetab =  table['query'] + table['table_name'] + table['columns'] +  ';'
        cursor.execute(queryrecreatetab)
        querybackup =  table['query'] + table['table_name'] + datetimestampvar + table['columns'] +  ';'
        cursor.execute(querybackup)
    #logger.info('Past creating tables in redshift')
    util_file.get_logger_info('Past creating tables in redshift')
    #logger.info(cursor.fetchall())
    connect.commit()
    cursor.close()
   # return None

def get_ssm(param_name):
    """
    This function reads a secure parameter from AWS' SSM service.
    The request must be passed a valid parameter name
    The parameter's value is returned.
    """
    #Create the SSM Client
    ssm = boto3.client('ssm', region_name='us-east-1')

    # Get the requested parameter
    response = ssm.get_parameters(Names=[param_name,],WithDecryption=True) 

    # Store the credentials in a variable
    credentials = response['Parameters'][0]['Value'] 

    return credentials


def export_and_backup_redshift(**kwargs):

    redshift_setup(dbname = get_ssm('redshift_qa_dbname'), host = get_ssm('redshift_qa_host'), 
                   port = get_ssm('redshift_qa_port'), user = get_ssm('redshift_qa_user_fab_team'), 
                   password = get_ssm('redshift_qa_password_fab_team'))

   # return None

def export_and_backup_redshift_op(dag, dag_name):
    # run_this = PythonOperator(
    #     task_id='insert_in_redshift_' + dag_name,
    #     provide_context=True,
    #     python_callable=export_and_backup_redshift,
    #     dag=dag)
    # return run_this

    return PythonOperator(
        task_id='insert_in_redshift_' + dag_name,
        provide_context=True,
        python_callable=export_and_backup_redshift,
        dag=dag)