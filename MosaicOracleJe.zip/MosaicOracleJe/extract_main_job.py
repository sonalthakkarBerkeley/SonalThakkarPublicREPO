### This is the main class and will call the extraction class###
from airflow import DAG
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.python_operator import PythonOperator
from airflow.contrib.operators.spark_sql_operator import SparkSqlOperator
from datetime import datetime, timedelta
from airflow.utils.trigger_rule import TriggerRule

import MosaicOracleJe.drop_db as DropDb
import MosaicOracleJe.extract as Extract
import MosaicOracleJe.post_to_redshift as PostToRedshift
import MosaicOracleJe.export_and_backup_redshift as ExportAndBackupRedshift
import MosaicOracleJe.transform as Transform
import MosaicOracleJe.transform_oracle_je_data as TransformOracleJeData
import MosaicOracleJe.transform_oracle_je_csv as TransformOracleJeCsvData
import MosaicOracleJe.transform_oracle_je_interco as TransformOracleJeIntercoData
import MosaicOracleJe.transform_oracle_je_data_platform_others as TransformOracleJeDataPlatformOthers

project_name = "ExtractMainJob"

default_args = {
	'owner': 'sonal',
	'depends_on_past': False,
	'start_date': datetime(2018, 6, 16),
	'retries': 1,
	'retry_delay': timedelta(minutes=0),
	'provide_context': True
	}

dag = DAG(
	project_name, 
	concurrency = 300, 
	schedule_interval = None, 
	default_args = default_args
	)


#call to drop and recreate redshift tables:
sub_dag_redshift_setup = ExportAndBackupRedshift.export_and_backup_redshift_op(dag, "ExportAndBackupRedshift")

# Delete tables from database by dropping entire db and then extract
sub_dag_drop = SubDagOperator( subdag = DropDb.drop_db(project_name, default_args), task_id = "DropDb", dag = dag)

#Extract =  Extract.Extract(project_name, default_args)
sub_dag_extract = SubDagOperator( subdag = Extract.extract(project_name, default_args), task_id = "Extract", dag = dag)

# Transform tables by joining hive temp tables
sub_dag_transform = SubDagOperator( subdag = Transform.transform(project_name, default_args), task_id = "Transform", dag = dag)

# Transform tables by joining hive oracle transformed tables
sub_dag_transform_oracle_je_data = SubDagOperator( subdag = TransformOracleJeData.transform_oracle_je_data(project_name, default_args), task_id = "TransformOracleJeData", dag = dag)

# Transform tables by joining hive oracle transformed tables
sub_dag_transform_oracle_je_data_platform_others = SubDagOperator( subdag = TransformOracleJeDataPlatformOthers.transform_oracle_je_data_platform_others(project_name, default_args), task_id = "TransformOracleJeDataPlatformOthers", dag = dag)

# Transform tables by joining hive temp tables
sub_dag_transform_interco = SubDagOperator( subdag = TransformOracleJeIntercoData.transform_oracle_je_interco(project_name, default_args), task_id = "TransformOracleJeIntercoData", dag = dag)

# Transform tables by joining hive oracle transformed tables
sub_dag_transform_oracle_je_csv = SubDagOperator( subdag = TransformOracleJeCsvData.transform_oracle_je_csv(project_name, default_args), task_id = "TransformOracleJeCsvData", dag = dag)

# Dropping and re-creating Redshift DBs#
sub_dag_redshift = SubDagOperator(subdag = PostToRedshift.post_to_redshift("/home/hadoop/airflow/dags/MosaicOracleJe/redshift_tables_setup.json", project_name, default_args), task_id = "PostToRedshift", dag = dag)

#call to ensure flow of jobs is recreate hive db, recreate tables on redshift, extract to hive, export to redshift
sub_dag_drop >> sub_dag_redshift_setup >> sub_dag_extract >> sub_dag_transform >> sub_dag_transform_oracle_je_data >> sub_dag_transform_oracle_je_data_platform_others >> sub_dag_transform_interco >> sub_dag_transform_oracle_je_csv >> sub_dag_redshift