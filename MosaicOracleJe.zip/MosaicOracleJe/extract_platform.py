### This is the extraction class for platform tables #
# This class calls the json file which will contain the list of table names and used the connection parameters to connect to platform and pull these tables#.
###

import json
from airflow import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
#from airflow.operators.subdag_operator import SubDagOperator
from datetime import datetime, timedelta


def extract_platform(config_file, parent_dag_name, default_args):
		with open(config_file) as handle:
			tbls = json.loads(handle.read())
		tables = tbls[0]['tables']
		airflow_connection_name = tbls[0]['tables']
		hive_schema = tbls[0]['hive_schema']
		#self.dag_childname = "ExtractPlatform"
		dag = DAG(
						'%s.%s' % (parent_dag_name, 'ExtractPlatform'),
						default_args    =  { 'provide_context': True },
						start_date      = datetime(2018, 6, 16))


		[ SqoopOperator(conn_id	 = 'mysql_sqoop', 
						task_id	 = table['table_name'], 
						cmd_type = "import" , 
						table 	 = table['table_name'], 
						split_by = table['split_by'], 
						extra_import_options = {
													"hive-table": hive_schema + '.' + table['table_name'], 
													"create-hive-table": "", 
													"delete-target-dir": "", 
													"hive-import": "", 
													#"map-column-hive": mosaic_oracle_platformtables['transformations']
													 "password-file": "file:///home/hadoop/airflow/dags/mysql-matillion_qa.password"
												}, 
						properties = { "mapreduce.job.queuename": "default" },
						provide_context = True, 
						dag = dag)
					for table in tables ]
		return dag