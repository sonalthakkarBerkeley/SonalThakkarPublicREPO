### This is the script to bring together fiel oracle_je_Csv table###
import json
from airflow import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
from airflow.operators.subdag_operator import SubDagOperator
from airflow.contrib.operators.spark_sql_operator import SparkSqlOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta


def transform_oracle_je_interco(parent_dag_name, default_args):

    file_infos = [{'name': 'transform_interco_cash', 'sql': "/home/hadoop/airflow/dags/MosaicOracleJe/transform_interco_cash.sql "}
                   ]


    dag_childname = 'TransformOracleJeIntercoData'

    dag = DAG('%s.%s' % (parent_dag_name, dag_childname), 
	    concurrency = 300, 
		default_args = default_args)

    [ SparkSqlOperator(task_id = file_name['name'], yarn_queue='default', name = file_name['name'], sql = file_name['sql'], provide_context = True, dag = dag)
	    	for file_name in file_infos ]
    return dag