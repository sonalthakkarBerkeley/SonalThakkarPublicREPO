# This class calls the json file which will contain the list of table names and used the connection parameters to connect to Redshift and pull these tables#.
###

import json
import MosaicOracleJe.util_file as util_file
from airflow import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
from airflow.operators.subdag_operator import SubDagOperator
from datetime import datetime, timedelta


def post_to_redshift(config_file, parent_dag_name, default_args):

		with open(config_file) as handle:
			tbls = json.loads(handle.read())
		tables = tbls[0]['tables']
		airflow_connection_name = tbls[0]['tables']
		hive_schema = tbls[0]['hive_schema']
		dag = DAG(
			            '%s.%s' % (parent_dag_name, 'PostToRedshift'),
						default_args    =  { 'provide_context': True },
						start_date      = datetime(2018, 6, 16))


    #datetimestampvar = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
		#if util_file.datetimestampvar != '':
			#datetimestampvar_local = util_file.datetimestampvar
		#else:
		datetimestampvar = util_file.get_date_timestamp()

		[ SqoopOperator(conn_id	 = 'mosaic_redshift_sqoop', 
						task_id	 = table['table_name'], 
						cmd_type = "export" , 
						table 	 = table['table_name'],  # "engineering.warehouse"
						extra_export_options = {
													"driver": "com.amazon.redshift.jdbc.Driver", 
													"hcatalog-table": table['hive_table_name'],
													"hcatalog-database": hive_schema, 
													"password-file": "file:///home/hadoop/airflow/dags/mosaic_redshift_qa.password"
												}, 
						dag = dag)
					for table in tables ]

		# [ SqoopOperator(conn_id	 = 'mosaic_redshift_sqoop', 
		# 				task_id	 = table['table_name'], 
		# 				cmd_type = "export" , 
		# 				table 	 = table['table_name'] + datetimestampvar,  # "engineering.warehouse"
		# 				extra_export_options = {
		# 											"driver": "com.amazon.redshift.jdbc.Driver", 
		# 											"hcatalog-table": table['hive_table_name'],
		# 											"hcatalog-database": hive_schema, 
		# 											"password-file": "file:///home/hadoop/airflow/dags/mosaic_redshift_qa.password"
		# 										}, 
		# 				dag = dag)
		# 			for table in tables ]

		return dag
