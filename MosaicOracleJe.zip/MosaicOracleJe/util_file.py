
from datetime import datetime, timedelta
import logging
import time, datetime, calendar
from dateutil.parser import parse
from datetime import timedelta

datetimestampvar_global = ''

project_static_map = {'ledger_id':	'300000001236001',
                      'status_code':	'NEW',
                      'currency':	'USD',
                      'journal_source':	'Platform',
                      'actual_flag':	'A',
                      'coa_seg_6':	'0000',
                      'coa_seg_7':	'00000',
                      'end_indicator':	'END'}


now = datetime.datetime.now()

def get_date_timestamp():	
	
	#if datetimestampvar_global = '':
	datetimestampvar = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
	return datetimestampvar


def get_logger_info(args):
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()
    return logger.info(args)

def get_current_date():
	datevar = datetime.datetime.now().strftime("%Y/%m/%d")
	return datevar