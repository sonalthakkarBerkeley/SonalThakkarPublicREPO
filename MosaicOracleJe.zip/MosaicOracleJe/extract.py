### This is the extraction class and will call the extraction platform (for platform tables) class###

from airflow import DAG
from airflow.operators.subdag_operator import SubDagOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta
import MosaicOracleJe.extract_platform as ExtractPlatform
import MosaicOracleJe.extract_redshift as ExtractRedshift

def extract(parent_dag_name, default_args):
    dag_childname = 'Extract'

    dag = DAG('%s.%s' % (parent_dag_name, dag_childname), 
    	      concurrency = 300,
    	      default_args = default_args)


	#ExtractPlatform = ExtractPlatform.ExtractPlatform("/home/hadoop/airflow/dags/MosaicOracleJe/mosaic_oracle_platform_tables.json", '%s.%s' % (parent_dag_name, "Extract"))
    SubDagOperator(subdag = ExtractPlatform.extract_platform("/home/hadoop/airflow/dags/MosaicOracleJe/mosaic_oracle_platform_tables.json", '%s.%s' % (parent_dag_name, 'Extract'), default_args), task_id = 'ExtractPlatform', dag = dag)
     
    SubDagOperator(subdag = ExtractRedshift.extract_redshift("/home/hadoop/airflow/dags/MosaicOracleJe/mosaic_oracle_redshift_tables.json", '%s.%s' % (parent_dag_name, 'Extract'), default_args), task_id = 'ExtractRedshift', dag = dag)    
  
    return dag