insert into oracle_staging.oracle_je_data
select  jed.id,
        jed.source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_debit,
        jed.gl_credit,
        string(YEAR(jed.gl_date) || '/' || LPAD(MONTH(jed.gl_date), 2, '0')|| '/' || LPAD(DAY(jed.gl_date), 2, '0')) as gl_date,
        string(YEAR(CURRENT_DATE()) || '/' || LPAD(MONTH(CURRENT_DATE()), 2, '0')|| '/' || LPAD(DAY(CURRENT_DATE()), 2, '0')) as effective_date,
        jed.facility_code,
        jed.facility_type_id,
        jed.on_book_facility,
        jed.gl_description,
        jed.coa_seg_1,
        jed.coa_seg_2,
        jed.coa_seg_4,
        '' as coa_seg_5,
        '' as transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
      --  jed.je_type || ' - ' || jed.batch_id || ' - ACH - ' || jed.bank_account_last_four as batch_name
        jed.je_type as batch_name
from oracle_staging.oracle_je_penny_test jed
union
select  jed.id,
        'je-engine-offset' as source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_credit gl_debit,
        jed.gl_debit gl_credit,
        string(YEAR(jed.gl_date) || '/' || LPAD(MONTH(jed.gl_date), 2, '0')|| '/' || LPAD(DAY(jed.gl_date), 2, '0')) as gl_date,
        string(YEAR(CURRENT_DATE()) || '/' || LPAD(MONTH(CURRENT_DATE()), 2, '0')|| '/' || LPAD(DAY(CURRENT_DATE()), 2, '0')) as effective_date,
        jed.facility_code,
        jed.facility_type_id,
        jed.on_book_facility,
        glm.description as gl_description,
        jed.coa_seg_1,
        jed.coa_seg_2,
        glm.gl_account_number coa_seg_4,
        '' as coa_seg_5,
        '' as transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
       -- jed.je_type || ' - ' || jed.batch_id || ' ACH - ' || jed.bank_account_last_four as batch_name
        jed.je_type as batch_name
from oracle_staging.oracle_je_penny_test jed
-- left join oracle_staging.oracle_gl_mapping glm on (jed.je_type = glm.je_type and jed.transcode = glm.concord_code)
cross join oracle_staging.general_ledger_account glm on (glm.description = 'G&A Exp. - Miscellaneous')
;

insert into oracle_staging.oracle_je_data
select  jed.id,
        jed.source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_debit,
        jed.gl_credit,
        string(YEAR(jed.gl_date) || '/' || LPAD(MONTH(jed.gl_date), 2, '0')|| '/' || LPAD(DAY(jed.gl_date), 2, '0')) as gl_date,
        string(YEAR(CURRENT_DATE()) || '/' || LPAD(MONTH(CURRENT_DATE()), 2, '0')|| '/' || LPAD(DAY(CURRENT_DATE()), 2, '0')) as effective_date,
        jed.facility_code,
        jed.facility_type_id,
        jed.on_book_facility,
        jed.gl_description,
        jed.coa_seg_1,
        jed.coa_seg_2,
        jed.coa_seg_4,
        '' as coa_seg_5,
        '' as transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
        jed.je_type || ' - ' || jed.batch_id || ' - ACH - ' || jed.bank_account_last_four as batch_name
from oracle_staging.oracle_je_installer_disbursement jed
union
select  jed.id,
        'je-engine-offset' as source, 
        jed.je_type,
        jed.batch_id,
        jed.loan_id,
        jed.gl_credit gl_debit,
        jed.gl_debit gl_credit,
        string(YEAR(jed.gl_date) || '/' || LPAD(MONTH(jed.gl_date), 2, '0')|| '/' || LPAD(DAY(jed.gl_date), 2, '0')) as gl_date,
        string(YEAR(CURRENT_DATE()) || '/' || LPAD(MONTH(CURRENT_DATE()), 2, '0')|| '/' || LPAD(DAY(CURRENT_DATE()), 2, '0')) as effective_date,
        jed.facility_code,
        jed.facility_type_id,
        jed.on_book_facility,
        glm.description as gl_description,
        jed.coa_seg_1,
        jed.coa_seg_2,
        glm.gl_account_number coa_seg_4,
        '' as coa_seg_5,
        '' as transcode,
        jed.lender_bank_account, 
        jed.deposit_bank_account, 
        jed.bank_account_last_four,
        jed.je_type || ' - ' || jed.batch_id || ' - ACH - ' || jed.bank_account_last_four as batch_name
from oracle_staging.oracle_je_installer_disbursement jed
-- left join oracle_staging.oracle_gl_mapping glm on (jed.je_type = glm.je_type and jed.transcode = glm.concord_code)
cross join oracle_staging.general_ledger_account glm on (glm.description = 'Suspense')
;